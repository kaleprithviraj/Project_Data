package com.cakeapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CakeAppBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
